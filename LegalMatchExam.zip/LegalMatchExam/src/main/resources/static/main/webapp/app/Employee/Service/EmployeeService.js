(function () {
    'use strict';

    angular
        .module('legalApp')
        .factory('EmployeeService', EmployeeService);

    EmployeeService.$inject = ['$http'];

    function EmployeeService($http) {
        var factory = {
        	getEmployeeList:getEmployeeList,  
        	saveEmployee:saveEmployee,
        	removeEmployee:removeEmployee,
        	activeUser:activeUser
    		
        };

        return factory;
        
        function getEmployeeList(pageIndex){
        	return $http({
                method: 'GET',
                url: 'Employee/' + pageIndex,
              //  params: paginationObject
            })
        }
        function saveEmployee(item){
        	return $http({
                method: 'POST',
                url: 'Employee',
                data: item
            })
        }
        
        function removeEmployee(id){
       	 	return $http({
                method: 'DELETE',
                url: 'Employee/' + id
            })
       }
        
        function activeUser(){
        	return $http({
                method: 'GET',
                url: 'Employee/activeUser'
            })
        }
       
    }
})();