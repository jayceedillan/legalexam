(function () {
    'use strict';

    angular
        .module('legalApp')
        .controller('LoginController', LoginController);

    LoginController.$inject = ['$state', '$rootScope','LoginDataService','ValidationService'];

    function LoginController($state,$rootScope, LoginDataService,ValidationService) {
    	
       var vm = this;
      
       vm.Login = Login;
       vm.user = {};

        function Login(loginForm){
        	if (ValidationService.isValid(loginForm) == 0){   
        		LoginDataService.login(vm.user)
                .then(function (result) { 
                	$rootScope.empInfo =result.data.loginName;
                	$state.go("Employee");
                 })
                .catch(function (error){
                	ValidationService.showAlert(error.data.header,error.data.error, 'gritter-error');               
               });        		
        	}
        //	
        }
    }

})();