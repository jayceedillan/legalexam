(function () {
    'use strict';

    angular
        .module('legalApp')
        .controller('EmployeeController', EmployeeController);
   
    EmployeeController.$inject = ['$state','employeeList','EmployeeService','LoginDataService','$uibModal','$q','ValidationService'];
    function EmployeeController($state,employeeList,EmployeeService,LoginDataService,$uibModal,$q,ValidationService) {
   
    	 var vm = this;
    	 vm.addOrUpdate= addOrUpdate;
    	 vm.addContact=addContact;
    	 vm.addAddressInfo=addAddressInfo;
    	 vm.saveEmployee=saveEmployee;
    	 vm.logout=logout;
    	 vm.processEmployee=processEmployee;
    	 vm.dateToday=new Date();
    	 vm.currentPage = 1;
    	 vm.pageChanged=pageChanged;
    	 vm.getAge=getAge;
    	 vm.clickRadio=clickRadio;
    	 vm.showDelete = true;
    	 vm.removeEmp=removeEmp;
    	 vm.cancel=cancel;
    	 vm.showAddOrUpdateForm=false;
    	 vm.Availability = new Date();
         vm.employeeList = employeeList.data.Employee;
         vm.totalItems = employeeList.data.totalItems;
         vm.reloadData= reloadData;
         vm.validateContactInfo=validateContactInfo;
         vm.validateAddressInfo=validateAddressInfo;
         vm.isValidDate=isValidDate;
         vm.validMultiInfo=validMultiInfo;
         vm.getYearsOfCompany=getYearsOfCompany;
         
         function getAge(DOB) {
        	    var today = new Date();
        	    var birthDate = new Date(DOB);
        	    var age = today.getFullYear() - birthDate.getFullYear();
        	    var m = today.getMonth() - birthDate.getMonth();
        	    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        	        age = age - 1;
        	    }

        	  return age;
         }
         

         function getYearsOfCompany(DOH) {
        	 
     		var y = 365;
     		var y2 = 31;     		
    		var today = new Date();     
    		var hiredDate = new Date(DOH);
    	    var timeDiff = Math.abs(today.getTime() - hiredDate.getTime());
           // days difference
            var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
    		var remainder = diffDays % y;           
           
     		var casio = remainder % y2;
     		var year = (diffDays - remainder) / y;
     		var month = (remainder - casio) / y2;
     		var result =year + "y" + " " + month + "m";
     		
     		return result;
     	}
      
         
//
//         function getYearsOfCompany(DOH) {
//     	    var today = new Date();
//     	    var hiredDate = new Date(DOH);
//     	    var yoc = today.getFullYear() - hiredDate.getFullYear();
//     	    var m = today.getMonth() - hiredDate.getMonth();
//     	    
//     	   var timeDiff = Math.abs(today.getTime() - hiredDate.getTime());
//
//           // days difference
//           var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
//
//           // difference
//           alert(diffDays);
//           
////     	    if (yoc <0){
////     	         return 0;
////     	    }
////     	    if (m<0){
////     	    	alert('m');
////     	    	return 0;
////     	    }
////     	    
//     	    
//     	    if (m > 0 || (m === 0 && today.getDate() > hiredDate.getDate())) {
//     	   return yoc + 'y' + ' ' + m + 'm';
//    	    }
//
//     	  return 0;
//        }

         
         function reloadData(){
        	 EmployeeService.getEmployeeList(vm.currentPage)
             .then(function (result) {     
            	 vm.employeeList = result.data.Employee;
              })
             .catch(function (error){
             	ValidationService.showAlert(error.data.header,error.data.error, 'gritter-error');               
            });  
         }
         
         function pageChanged(){
        	 vm.reloadData();
        	 //vm.currentPage++;
         }
         function addOrUpdate(data){
        	 vm.showAddOrUpdateForm=true;
        	 vm.employeeInfo ={};
        	 
        	 if (data !=null){
        		 vm.showDelete = true;
        		 angular.copy(data,vm.employeeInfo);
        		//vm.employeeInfo = data; 
        		vm.employeeInfo.empInfo.birthdate = new Date(vm.employeeInfo.empInfo.birthdate);
        		vm.employeeInfo.empInfo.datehired = new Date(vm.employeeInfo.empInfo.datehired);
        	 }else{
        		 vm.showDelete = false;
        		 vm.employeeInfo['empInfo']={};
        		 vm.employeeInfo['addressInfo']={}; 
        		 vm.employeeInfo['contactInfo']={};
        	 }
         }
         function clickRadio(item,isCheck,data){
        	 setUnchecked(data);        	 
        	 item._primary=isCheck;
         }
         function setUnchecked(data){
        	 angular.forEach(data, function(value, key) {	            		  
        		value._primary=false;
        	});     
         }
         function removeEmp(empId){
        	 
        	 // i used this confirm for temporary
        	 // 
        	 var reply = confirm("Are you sure you want remove this employee?"); 
       
	          if (reply){       
	            EmployeeService.removeEmployee(empId)
	            .then(function (result) {     
	           	   vm.reloadData();
  	           	   vm.showAddOrUpdateForm=false;
	           	   ValidationService.showAlert('Success','Employee successfully removed','gritter-success');
	             })
	            .catch(function (error){
	            	ValidationService.showAlert(error.data.header,error.data.error, 'gritter-error');               
	           });  
	          }
         }
         
         function cancel(form){
        	 vm.showAddOrUpdateForm=false;
        	 form.$setUntouched();
 		     form.$setPristine();
         }
         
         function addContact(){ vm.employeeInfo.empInfo
        	 var contactInfoList = [{value:'',_primary:false}];         
        	 if (!angular.isUndefined( vm.employeeInfo.contactInfoList)){
        	     vm.employeeInfo.contactInfoList.push({value:'',_primary:false,employees:vm.employeeInfo.empInfo});        	    
        	    
        	 }else{        		
        		 vm.employeeInfo['contactInfoList']= contactInfoList;
        		 vm.employeeInfo.contactInfoList['employees'] =[];
        		 vm.employeeInfo.contactInfoList.employees.push( vm.employeeInfo.empInfo);
        	 }
         }
         
         function addAddressInfo()
         {
        	 var addressInfoList = [{address1:'',address2:'',_primary:false}];        	 
        	 if (!angular.isUndefined( vm.employeeInfo.addressInfoList)){
        		 vm.employeeInfo.addressInfoList.push({address1:'',address2:'',_primary:false,employees:vm.employeeInfo.empInfo});        		 
          	 }else{          		 
          		 vm.employeeInfo['addressInfoList']= addressInfoList;
          		vm.employeeInfo.addressInfoList['employees'] =vm.employeeInfo.empInfo;
          	 }
         }
         
         function saveEmployee(form){
        	 if (ValidationService.isValid(form) == 0 && formDateValidation(form) == 0){        		
                   vm.validMultiInfo(form);
                }
         }
         
         function validMultiInfo(form)
         {

        	 var hasError=0;
	    	 vm.validateContactInfo().then(function(result){
			   if(!result){
				   ValidationService.showAlert('Required','Please specify contact info.','gritter-error');		   

			   }
    			   else{
    				   vm.validateAddressInfo().then(function(result){
    					   if(!result){
    						  ValidationService.showAlert('Required','Please specify Address 1 or Address 2.','gritter-error');    				          
    					   }else{
    						   vm.processEmployee();
    						   form.$setUntouched();
    						   form.$setPristine();
    					   }
    				   })
    			   }
			   })
		  }
         
        function processEmployee(){
	  		 EmployeeService.saveEmployee(vm.employeeInfo)
	             .then(function (result) {     
	             	vm.reloadData();
	             	vm.showAddOrUpdateForm=false;
	             	vm.employeeInfo={};
	             	ValidationService.showAlert('Success','Employee successfully saved','gritter-success');
	              })
	         .catch(function (error){
	         	ValidationService.showAlert(error.data.header,error.data.error, 'gritter-error');               
	        });   
         }
         function validateContactInfo(){
    	     var defer = $q.defer()
    	     var valid = false;
        	 if (angular.isUndefined(vm.employeeInfo.contactInfoList)){
        		 defer.resolve(false);
        		 return defer.promise;
        	 }
        	 else{
    	        angular.forEach(vm.employeeInfo.contactInfoList, function(item){
        		    if(item._primary == true && item.value !="" && item.value.length < 150){        		    	
        		    	valid = true
        		        return;
        		    }        		   
        		  });   
        	 }
        	 
	        if (valid){defer.resolve(true);}else{defer.resolve(false);}
	 
	        return defer.promise;
        	 
         }
         
         function validateAddressInfo(){

        	 var defer = $q.defer()
    	     var valid = false;
        	 if (angular.isUndefined(vm.employeeInfo.addressInfoList)){
        		 defer.resolve(false);
        		 return defer.promise;
        	 }
        	 else{
    	        angular.forEach(vm.employeeInfo.addressInfoList, function(item){
        		    if(item._primary == true &&  ((item.address1 !="" || item.address2 !="") && (item.address1.length < 150 &&  item.address2.length < 150))){        		    	
        		    	valid = true
        		        return;
        		    }        		   	
        		  });   
        	 }
        	 
	        if (valid){defer.resolve(true);}else{defer.resolve(false);}
	 
	        return defer.promise;	        
        	 
         }
         
         function formDateValidation(form){
        	 
        	 var CurrentDate = new Date();
        	 var birthDate = new Date(form.inputBirthDate.$viewValue);
        	 
        	 if(birthDate > CurrentDate){
        		ValidationService.showAlert('Invalid Date','Birth date is greater than the current date.','gritter-error');
      		    form.inputBirthDate.$invalid = true;
      		    form.inputBirthDate.$setDirty();
      		    return 1;
        	 }
        	 
        	 if (!vm.isValidDate(form.inputBirthDate.$viewValue)){
     		    ValidationService.showAlert('Invalid Date','Invalid date format','gritter-error');
     		    form.inputBirthDate.$invalid = true;
     		    form.inputBirthDate.$setDirty();
     		    return 1;
     		 }
     		 
     		 if (!vm.isValidDate(form.inputDateHired.$viewValue)){
      		     ValidationService.showAlert('Invalid Date','Invalid date format','gritter-error');
      		     form.inputDateHired.$invalid = true;
      		     form.inputDateHired.$setDirty();
      		    return 1;
      		 }
     		 
     		 return 0;
         }
         function isValidDate(dateString) {
        	  var regEx = /^\d{4}-\d{2}-\d{2}$/;
        	  if(!dateString.match(regEx)) return false;  // Invalid format
        	  var d = new Date(dateString);
        	  var dNum = d.getTime();
        	  if(!dNum && dNum !== 0) return false; // NaN value, Invalid date
        	  return d.toISOString().slice(0,10) === dateString;
        	}

          function logout(){
        	  LoginDataService.logout();
        	  LoginDataService.logout()
              .then(function (result) {     
            	  $state.go("Login");
               }); 
          }
//         function addOrUpdate(){
//        	 $uibModal.open({
//			     templateUrl: '/main/webapp/app/Employee/Controller/AddUpdateEmployee.html',				 
//				// controller: 'ViewStockController',
//				// controllerAs: 'vmViewStock',
//			     backdrop: 'static',
//				 keyboard: false,
//				
////				 resolve: {
////	                    Items: [
////	                        function () {  
////	                            return ItemsService.getItemsById(itemId.id)
////	                        }]
////	                }
//			
//			  });
//         }
    }
    

})();
