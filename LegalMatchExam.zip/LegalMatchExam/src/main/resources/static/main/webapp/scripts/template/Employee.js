app.directive("newEmployee", function() {
  return {
    restrict: "A",   
    templateUrl: "/main/webapp/app/Employee/Controller/AddUpdateEmployee.html",
//    controller: 'newEmployeeController',
//    controllerAs: 'vmNewEmployee',
    //replace:true,
    //bindToController: true
  };
});

//app.directive("validateDate", function() {
//    return {
//        require: 'ngModel',
//        link: function(scope, elm, attrs, ctrl) {
//        	alert('xxx');
//            ctrl.$validators.validateDate = function(modelValue, viewValue) {
//                if(!isNaN(modelValue) || ctrl.$isEmpty(modelValue)){
//                    return true;
//                }
//                return false;
//            };
//        }
//    };
//})
