(function () {
    'use strict';

    angular
        .module('legalApp')
        .controller('newEmployeeController', newEmployeeController);
   
    newEmployeeController.$inject = ['EmployeeService'];
    function newEmployeeController(EmployeeService) {
   
    	 var vm = this;
         
    	 vm.newEmployee ={};    	 
    	 vm.saveEmployee=saveEmployee;
    	 vm.removeEmployee=removeEmployee;
    	 
    	 function saveEmployee(){
    		 alert('xxx');
    	 }
    	 
    	 function removeEmployee(){
    		 
    	 }
        
    }

})();
