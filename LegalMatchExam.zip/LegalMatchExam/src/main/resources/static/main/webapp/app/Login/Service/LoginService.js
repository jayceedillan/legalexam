(function () {
    'use strict';

    angular
        .module('legalApp')
        .factory('LoginDataService', LoginDataService);

    LoginDataService.$inject = ['$http'];

    function LoginDataService($http) {
        var factory = {
    		login: login,
    		logout:logout
    	
        };

        return factory;
        
        function login(user) {        	
        	   return $http({
                   method: 'POST',
                   url: 'Login',
                   params: {loginName : user.loginName,
                   		 password: user.loginPassword}
               })
        }
       
        function logout() {  		
        	return $http({
                method: 'POST',
                url: 'Login/Logout'
            })

    	  }
        
    }

})();