var app = angular.module('legalApp', ['ui.router',
	'ngSanitize','ui.bootstrap']).run(run);

run.$inject = ['stateHandler'];
function run(stateHandler) {	
    stateHandler.initialize();
}
