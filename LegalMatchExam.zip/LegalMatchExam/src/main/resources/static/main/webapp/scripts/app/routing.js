

app.config(function($stateProvider, $urlRouterProvider,$urlMatcherFactoryProvider,$locationProvider) {

	$locationProvider.html5Mode(true);
    $urlRouterProvider.otherwise("Login");
    $locationProvider.hashPrefix('');	
    $stateProvider
		.state('Login',{
            templateUrl:'/main/webapp/app/Login/Controller/Login.html',
            url:'/Login',
            controller: 'LoginController',
            controllerAs: 'vmLogin'
            
        }).state('Employee',{
            templateUrl:'/main/webapp/app/Employee/Controller/Employee.html',
            url:'/Employee',
            controller: 'EmployeeController',
            controllerAs: 'vmEmployee',
            resolve: {
                employeeList: ['EmployeeService',
                    function (EmployeeService) {                 	      
                        return EmployeeService.getEmployeeList(1);
                    }]
              
            } 
            
        });
      
       
    
});




