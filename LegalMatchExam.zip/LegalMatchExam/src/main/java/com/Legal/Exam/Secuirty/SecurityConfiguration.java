package com.Legal.Exam.Secuirty;

import javax.inject.Inject;

import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;



@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Inject
    private AjaxLogoutSuccessHandler ajaxLogoutSuccessHandler;

    @Inject
    private Http401UnauthorizedEntryPoint http401UnauthorizedEntryPoint;

    @Override
    public void configure(WebSecurity web) throws Exception {
    
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {


    	 http.httpBasic().and().csrf().disable().exceptionHandling().authenticationEntryPoint(http401UnauthorizedEntryPoint).and()
//    	  .addFilterBefore(new UniqueRequestTokenGeneratorFilter(),
//    	  UsernamePasswordAuthenticationFilter.class)    	 
    	 .logout().logoutUrl("/api/logout").logoutSuccessHandler(ajaxLogoutSuccessHandler).deleteCookies("JSESSIONID").permitAll().and()    	 
    	 .authorizeRequests().antMatchers("Login/**").permitAll().antMatchers("/Employee").authenticated();
    	
    }

}
