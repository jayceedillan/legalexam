package com.Legal.Exam.Config;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

public class WebConfig extends WebMvcConfigurerAdapter {

    @Controller
    static class DefaultRoute {
        @RequestMapping({"/", "Login","Employee"})
        public String index() {
            return "forward:/main/Webapp/index.html";
        }
    }
}