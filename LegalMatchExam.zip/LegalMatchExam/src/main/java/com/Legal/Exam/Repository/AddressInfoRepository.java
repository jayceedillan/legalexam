package com.Legal.Exam.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.Legal.Exam.Entities.AddressInfo;

@Repository
public interface AddressInfoRepository extends CrudRepository<AddressInfo, Integer>{
	//@Query("select a from addressinfo a where a.fk_employee_id =:fk_employee_id")
	//addressinfo findByForenameAndSurname(@Param("fk_employee_id") int fk_employee_id);
	List<AddressInfo> findById(int id);
}
