package com.Legal.Exam.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Legal.Exam.Entities.ContactInfo;
import com.Legal.Exam.Entities.Employee;

@Repository
public interface ContactInfoRepository extends CrudRepository<ContactInfo, Integer>{
     
	
}