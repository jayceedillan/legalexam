package com.Legal.Exam.Controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import javax.inject.Inject;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.Legal.Exam.DTO.EmployeeInfoDTO;
import com.Legal.Exam.Entities.Employee;
import com.Legal.Exam.Entities.Users;
import com.Legal.Exam.Secuirty.SecurityUtil;
import com.Legal.Exam.Service.EmployeeService;


import ch.qos.logback.core.net.SyslogOutputStream;


@RestController
@RequestMapping(value = "Employee", produces = MediaType.APPLICATION_JSON_VALUE)
public class EmployeeController {

	@Inject
    private EmployeeService employeeService;
	 
	 
	@RequestMapping(value = "{pageIndex}",method = RequestMethod.GET)
    public Map<String, Object> getEmployees(@PathVariable int pageIndex) throws SQLException {
		 List<EmployeeInfoDTO> empRepo=new ArrayList<EmployeeInfoDTO>();
		 AtomicInteger totalItems = new AtomicInteger(0);
		 
		 try {					 					 
			 empRepo = employeeService.getEmployeeList(pageIndex,totalItems);					 
		} catch (Exception e) {
			// TODO: handle exception		
		}        
 
        Map<String, Object> empMap = new HashMap<>();
        empMap.put("Employee", empRepo);
        empMap.put("totalItems", totalItems);
        return empMap;
    }	
	 
	 @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	  public Map<String, Object> saveEmployees(@RequestBody EmployeeInfoDTO employeeInfoDTO) throws SQLException {
		 
		 employeeService.addOrUpdateEmployee(employeeInfoDTO); 
  		 Map<String, Object> empMap = new HashMap<>();  
	     empMap.put("Employee", null); 
	    
	    return empMap;
	 }  
	  
	 
	 @RequestMapping(value = "/activeUser", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public Map<String, Object> validateActiveUser() throws Exception {

			Users authenticationData = SecurityUtil.getCurrentLogin();

			Map<String, Object> result = new HashMap<>();
			result.put("authenticationData", authenticationData);			

			return result;
		}
	 
	 
	 @RequestMapping(value = "{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean removeEmployee(@PathVariable int id) {
	 employeeService.removeEmployee(id);
	 
	 return true;
    }
}
  