package com.Legal.Exam.Secuirty;

import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import com.Legal.Exam.Entities.Users;

public class SecurityUtil {

    public final static String NO_USER = "No user currently logged in";

    public static Users getCurrentLogin() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        if (authentication != null) {
            if (authentication.getPrincipal() instanceof Users) {

                return (Users) authentication.getPrincipal();
            }
        }
        throw new AuthenticationCredentialsNotFoundException(NO_USER);
    }
}