package com.Legal.Exam.Entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "contactinfo")
public class ContactInfo implements Serializable{
     
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
     
    @Column(name="value",  length=150)
    private String value;
      
    @Column(name="is_primary")
    private boolean is_primary = false;

    
    @ManyToOne
    @JoinColumn(name ="FK_employee_id")
    private Employee employees;
     
    public ContactInfo() {
         
    }
     
    public ContactInfo(String value, boolean is_primary, Employee employees) {
        this.value = value;        
        this.is_primary=is_primary;
        this.employees = employees;
    }
}