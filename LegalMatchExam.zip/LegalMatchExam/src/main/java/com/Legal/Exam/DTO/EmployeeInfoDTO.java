package com.Legal.Exam.DTO;

import java.util.List;
import java.util.Set;

import com.Legal.Exam.Entities.AddressInfo;
import com.Legal.Exam.Entities.ContactInfo;
import com.Legal.Exam.Entities.Employee;

import lombok.Data;

@Data
public class EmployeeInfoDTO {

	
	private Employee empInfo;
	private AddressInfo addressInfo;
	private List<AddressInfo> addressInfoList;
	private List<ContactInfo> ContactInfoList;
	private ContactInfo contactInfo;
	private int totalItems;	
}
