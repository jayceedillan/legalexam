package com.Legal.Exam.Repository;

import java.awt.print.Pageable;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Legal.Exam.Entities.Employee;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Integer>{
     
	//List<Employee> findAll(Pageable pageable);
	 Page<Employee> findAll(org.springframework.data.domain.Pageable pageable);
	 
	//List<Employee> testLang(Pageable pageable);
}