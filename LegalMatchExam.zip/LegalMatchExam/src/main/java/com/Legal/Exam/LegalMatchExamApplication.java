package com.Legal.Exam;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.Legal.Exam.Service.EmployeeService;




@SpringBootApplication
@EnableJpaAuditing
public class LegalMatchExamApplication  implements CommandLineRunner  {

	  @Autowired
      EmployeeService employeeService;
    
	 
	public static void main(String[] args) {	
		//SessionFactory sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
		
		SpringApplication.run(LegalMatchExamApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		employeeService.initEmployee();
	}

}
