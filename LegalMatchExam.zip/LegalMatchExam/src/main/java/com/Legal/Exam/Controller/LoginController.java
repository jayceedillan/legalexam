package com.Legal.Exam.Controller;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Legal.Exam.LegalMatchExamApplication;
import com.Legal.Exam.Common.AlertResponse;
import com.Legal.Exam.Common.Messages;
import com.Legal.Exam.Entities.Users;
import com.Legal.Exam.Service.LoginService;
import com.Legal.Exam.Service.RespService;

@RestController
@RequestMapping("Login")
public class LoginController {

	@Inject
    private LoginService loginService;

    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> login(@RequestParam(required = true) String loginName, @RequestParam(required = true) String password) throws Exception {
    	
    	 Users authenticationData = new Users();
    	String invalidUser = this.loginService.validateUser(loginName,password);
	   
    	if (invalidUser !=null){
	    	  authenticationData.setLoginName(invalidUser);
	    	   Authentication authentication = new UsernamePasswordAuthenticationToken(authenticationData, null, null);
	    	  SecurityContext c = SecurityContextHolder.getContext();
	          c.setAuthentication(authentication);	          
	          return ResponseEntity.ok().headers(AlertResponse.error("")).body(authenticationData);
	
	    }
	    
	    return ResponseEntity.badRequest().headers(AlertResponse.success(""))
	            .body(RespService.responseError(Messages.FAILED_HEADER, Messages.UserAuthentication.INVALID_USER));
	    
	    }
    
    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, value = "/Logout")
    public ResponseEntity<Object> Logout(HttpSession session) {
        session.invalidate();
        return null;
    }
}
