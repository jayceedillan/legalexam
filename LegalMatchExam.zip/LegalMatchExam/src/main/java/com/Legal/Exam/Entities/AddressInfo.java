package com.Legal.Exam.Entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "addressinfo")
public class AddressInfo implements Serializable{
     
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
     
    @Column(name="address1",  length=150)
    private String address1;
      
    @Column(name="address2",  length=150)
    private String address2;

    @Column(name="is_primary")
    private boolean is_primary = false;

    
    @ManyToOne
    @JoinColumn(name ="FK_employee_id",referencedColumnName = "id")
    private Employee employees;
     
    public AddressInfo() {
         
    }
     
    public AddressInfo(String address1,String address2, boolean is_primary, Employee employees) {
        this.address1 = address1;
        this.address2=address2;
        this.is_primary=is_primary;
        this.employees = employees;
    }
}