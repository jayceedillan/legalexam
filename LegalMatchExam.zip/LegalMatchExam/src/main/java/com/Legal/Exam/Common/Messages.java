package com.Legal.Exam.Common;

public class Messages {
	public static final String SUCCESS_HEADER = "SUCCESS.";
	  public static final String FAILED_HEADER = "FAILED.";
	 public class UserAuthentication {
	        public static final String SUCCESS_USER = "User successfully login.";
	        public static final String INVALID_USER = "Login name or password invalid.";
	        
	    }
}
