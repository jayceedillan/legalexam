package com.Legal.Exam.Service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {

	 public String validateUser(String loginName, String password) {
		 
		  if (loginName.equals("admin") && password.equals("admin")) {
			  return "admin";
		  }else if (loginName.equals("standard") && password.equals("standard")) {
			  return "standard";
		  }
	        
		  return null;
	    }
}
