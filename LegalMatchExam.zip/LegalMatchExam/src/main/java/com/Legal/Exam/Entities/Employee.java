package com.Legal.Exam.Entities;

import java.io.Serializable;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "employee")
public class Employee implements Serializable{
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public Date getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

	public Date getDatehired() {
		return datehired;
	}

	public void setDatehired(Date datehired) {
		this.datehired = datehired;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Column(length=50, nullable= false)
	private String fname;
	@Column(length=50, nullable= false)
	private String mname;
	@Column(length=50, nullable= false)
	private String lname;	
	
   @Column(length=10, nullable= false)
   private String gender;
	
	@Column(length=50, nullable= false)
	private String position;
	public String getMaritalstatus() {
		return maritalstatus;
	}

	public void setMaritalstatus(String maritalstatus) {
		this.maritalstatus = maritalstatus;
	}

	@Column( nullable= false)
	private Date birthdate;
	@Column( nullable= false)
	private Date datehired;
	
	@Column(length=50, nullable= false)
	private String maritalstatus;
	
	@OneToMany(mappedBy="employees", cascade = CascadeType.ALL)
	Set<AddressInfo> addressInfo = new HashSet<AddressInfo>();
	
	@OneToMany(mappedBy="employees", cascade = CascadeType.ALL)
	Set<ContactInfo> contactInfo = new HashSet<ContactInfo>();
	

	public Set<ContactInfo> getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(Set<ContactInfo> contactInfo) {
		this.contactInfo = contactInfo;
	}

	public Employee() {
		  
	}
	
	public Employee(String fname,String mname,String lname,String gender,String position, String maritalstatus,Date birthdate,Date datehired) {
		
		this.fname = fname;
		this.mname=mname;
		this.lname= lname;
		this.gender=gender;
		this.position =position;
		this.maritalstatus=maritalstatus;
		this.birthdate = birthdate;
		this.datehired = datehired;
				
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public Set<AddressInfo> getAddressInfo() {
		return addressInfo;
	}

	public void setAddressInfo(Set<AddressInfo> addressInfo) {
		this.addressInfo = addressInfo;
	}
}