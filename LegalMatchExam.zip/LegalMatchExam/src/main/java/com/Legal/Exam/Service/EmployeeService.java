package com.Legal.Exam.Service;


import java.sql.Date;
import java.text.ParseException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.Legal.Exam.DTO.EmployeeInfoDTO;
import com.Legal.Exam.Entities.AddressInfo;

import com.Legal.Exam.Entities.ContactInfo;
import com.Legal.Exam.Entities.Employee;

import com.Legal.Exam.Repository.EmployeeRepository;
import com.Legal.Exam.Repository.AddressInfoRepository;
import com.Legal.Exam.Repository.ContactInfoRepository;

@Service
public class EmployeeService {

	@Inject
    private EmployeeRepository employeeRepository;
	
	@Inject
    private AddressInfoRepository AddressInfoRepository;
	
	@Inject
    private ContactInfoRepository contactInfoRepository;
	
	
	  @Transactional
	  public void initEmployee() throws ParseException {	  
	    
		   java.util.Calendar cal = Calendar.getInstance();
		   java.util.Date utilDate = new java.util.Date(); // your util date
		   
		   
		   java.sql.Date bdate = new java.sql.Date(cal.getTime().getTime()); // your sql date
		   bdate.setDate(bdate.getDate()-1000);
		   
		  
		     Employee emp1 = new Employee("Jessie 1","Palete","Furigay","Male","Team Lead","Single",bdate,bdate);
	         
	         Set address1 = new HashSet();
	         address1.add(new AddressInfo("Las Pinas 1", "Las Pinas 2",true, emp1));
	         address1.add(new AddressInfo("Las Pinas 11", "Las Pinas 22",false, emp1));
	         address1.add(new AddressInfo("Las Pinas 13", "Las Pinas 23",false, emp1));
	         emp1.setAddressInfo(address1);
	         
	         Set contactInfo1 = new HashSet();
	         
	         contactInfo1.add(new ContactInfo("123455", true, emp1));
	         contactInfo1.add(new ContactInfo("1234556", false, emp1));
	         contactInfo1.add(new ContactInfo("1234556", false, emp1));
	         emp1.setContactInfo(contactInfo1);
	         
             Employee emp2 = new Employee("Jessie 2","Palete","Furigay","Male","Team Lead","Married",bdate,bdate);            
             Set address2 = new HashSet();
             address2.add(new AddressInfo("Las Pinas 3", "Las Pinas 4",true, emp2));
             address2.add(new AddressInfo("Las Pinas 3", "Las Pinas 4",false,emp2));
             address2.add(new AddressInfo("Las Pinas 3", "Las Pinas 4",false, emp2));
             emp2.setAddressInfo(address2);
             
			 Set contactInfo2 = new HashSet();			     
			 contactInfo2.add(new ContactInfo("00000000", true, emp2));
			 contactInfo2.add(new ContactInfo("000000001", false, emp2));
			 contactInfo2.add(new ContactInfo("000000002", false, emp2));
			 emp2.setContactInfo(contactInfo2);
	                  	       
             Employee emp3 = new Employee("Jessie 3","Palete","Furigay","Male","Team Lead","Single",bdate,bdate);	       
             Set address3 = new HashSet();
             address3.add(new AddressInfo("Las Pinas 5", "Las Pinas 6",true, emp3));
             address3.add(new AddressInfo("Las Pinas 5", "Las Pinas 6",false, emp3));
             address3.add(new AddressInfo("Las Pinas 5", "Las Pinas 6",false, emp3));
             emp3.setAddressInfo(address3);
	         
             Set contactInfo3 = new HashSet();			     
             contactInfo3.add(new ContactInfo("11111111", true, emp3));
			 contactInfo3.add(new ContactInfo("1111110", false, emp3));
			 contactInfo3.add(new ContactInfo("1111112", false, emp3));
			 emp3.setContactInfo(contactInfo3);	                  	     
	       
	         Set employees = new HashSet();
	         employees.add(emp1);
	         employees.add(emp2);
	         employees.add(emp3);
	         employeeRepository.save(employees);
	       
	  } 
	    
	  public List<EmployeeInfoDTO> getEmployeeList(int pageIndex,AtomicInteger totalItems) {
		  List<EmployeeInfoDTO> employeeInfoList = new ArrayList<EmployeeInfoDTO>();
		 try {
          pageIndex--;
		  Pageable pageable =new PageRequest(pageIndex, 10,Direction.ASC,"id");
		  Page<Employee> page = employeeRepository.findAll(pageable);
		  int icount =(int) (long) employeeRepository.count();
		  totalItems.set(icount);
		  
		  for (Employee employee : page) {
			  employeeInfoList.add(employeeMapper(employee));
		    }
		  
		  } catch (Exception e) {
			System.out.println(e);
				
		} 
		 
		  return employeeInfoList;

	  }

	  
	  public EmployeeInfoDTO employeeMapper(Employee empData) {
		  
		  EmployeeInfoDTO employeeInfoDTO = new EmployeeInfoDTO();
		  Employee emp = new Employee();
		  
		  emp.setId(empData.getId());
		  emp.setBirthdate(empData.getBirthdate());
		  emp.setDatehired(empData.getDatehired());
		  emp.setFname(empData.getFname());
		  emp.setLname(empData.getLname());
		  emp.setMname(empData.getMname());
		  emp.setGender(empData.getGender());
		  emp.setPosition(empData.getPosition());
		  emp.setMaritalstatus(empData.getMaritalstatus());
 	  
		  AddressInfo addressInfo  = empData.getAddressInfo().stream()                      
	                .filter(x -> x.is_primary() == true)
	                .findAny()
	                .orElse(null);

		  AddressInfo addressInfos = new AddressInfo();
		  addressInfos.setEmployees(emp);
		  addressInfos.setAddress1(addressInfo.getAddress1());
		  addressInfos.setAddress2(addressInfo.getAddress2());
		  addressInfos.set_primary(addressInfo.is_primary());
		  
		  ContactInfo contactInfo  = empData.getContactInfo().stream() 
          .filter(x -> x.is_primary() == true)  
          .findAny() 
          .orElse(null); 

		  ContactInfo contactInfos = new ContactInfo();
		  contactInfos.setEmployees(emp);
		  contactInfos.setValue(contactInfo.getValue());		  
		  contactInfos.set_primary(contactInfos.is_primary());
		  
		  List<AddressInfo>  arrAddressInfo= new ArrayList<AddressInfo>();
		  for (AddressInfo ai : empData.getAddressInfo()) {
			  AddressInfo a2 = new AddressInfo();
			  a2.setId(ai.getId());
			  a2.setEmployees(emp);
			  a2.setAddress1(ai.getAddress1());
			  a2.setAddress2(ai.getAddress2());
			  a2.set_primary(ai.is_primary());
			  arrAddressInfo.add(a2);
		  } 
		  
		  List<ContactInfo>  arrContactInfo= new ArrayList<ContactInfo>();
		  for (ContactInfo ai : empData.getContactInfo()) {
			  ContactInfo a2 = new ContactInfo();
			  a2.setId(ai.getId());
			  a2.setEmployees(emp);
			  a2.setValue(ai.getValue());
			  a2.set_primary(ai.is_primary());
			  arrContactInfo.add(a2);
		  } 
		  		  
		  employeeInfoDTO.setContactInfoList(arrContactInfo);
		  employeeInfoDTO.setAddressInfoList(arrAddressInfo);
		  employeeInfoDTO.setEmpInfo(emp);
		  employeeInfoDTO.setContactInfo(contactInfos);
		  employeeInfoDTO.setAddressInfo(addressInfos);		  
		  
		  return employeeInfoDTO;
	  }	  

	  public boolean addOrUpdateEmployee( EmployeeInfoDTO employeeInfoDTO) {
		  
		  Employee emp3 = new Employee();
		  
		  if (employeeInfoDTO.getEmpInfo().getId() ==0) {
			  Set address1 = new HashSet();
			  Set contactInfo3 = new HashSet();
			  emp3 = new Employee(employeeInfoDTO.getEmpInfo().getFname(),employeeInfoDTO.getEmpInfo().getMname(),employeeInfoDTO.getEmpInfo().getLname(),
					  employeeInfoDTO.getEmpInfo().getGender(),employeeInfoDTO.getEmpInfo().getPosition(),employeeInfoDTO.getEmpInfo().getMaritalstatus(),employeeInfoDTO.getEmpInfo().getBirthdate(),employeeInfoDTO.getEmpInfo().getDatehired());
			  
			  for (AddressInfo ai : employeeInfoDTO.getAddressInfoList()) {
			      address1.add(new AddressInfo(ai.getAddress1(), ai.getAddress2(),ai.is_primary(), emp3));
			  }
			  emp3.setAddressInfo(address1);
			  
			  for (ContactInfo ci : employeeInfoDTO.getContactInfoList()) {
				  contactInfo3.add(new ContactInfo(ci.getValue(), ci.is_primary(), emp3));				  		         
			  }
			  emp3.setContactInfo(contactInfo3);
			  
		  }else {
		    emp3 = employeeInfoDTO.getEmpInfo();
		    
		    Set<AddressInfo> address3 = new HashSet<AddressInfo>(employeeInfoDTO.getAddressInfoList());
		    
            emp3.setAddressInfo(address3);		         
	        Set< ContactInfo>contactInfo3 = new HashSet<ContactInfo>(employeeInfoDTO.getContactInfoList());
	        emp3.setContactInfo(contactInfo3);
		  }
		  
//		      for (AddressInfo ai : employeeInfoDTO.getAddressInfoList()) {
//			      address1.add(new AddressInfo(ai.getAddress1(), ai.getAddress2(),ai.is_primary(), emp3));
//			  }
//			emp3.setAddressInfo(address1);
//			  
//			  for (ContactInfo ci : employeeInfoDTO.getContactInfoList()) {
//				  contactInfo3.add(new ContactInfo(ci.getValue(), ci.is_primary(), emp3));				  		         
//			  }
//			emp3.setContactInfo(contactInfo3);
			  
		  Set employees = new HashSet();
		  employees.add(emp3);
		  try {
			  employeeRepository.save(employees);
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
		  
		//  contactInfoRepository.save(employeeInfoDTO.getContactInfoList());
		  return true;
	  }
	  
	  public boolean removeEmployee(int id) {
		  
		  boolean isSuccess = true;
		  try {
				  employeeRepository.delete(id);
			} catch (Exception e) {
				isSuccess = false;
			}
	 	 return isSuccess;
	  }
}
