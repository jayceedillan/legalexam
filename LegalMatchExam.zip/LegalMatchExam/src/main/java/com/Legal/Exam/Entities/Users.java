package com.Legal.Exam.Entities;

import lombok.Data;

@Data
public class Users {
	private String loginName;
}
